
/* load a prolog source file 'File' into a list term 'Src' */

input_file(File, Src) :- 
    open(File,read,ID),
    read_file(ID,Src),
    close(ID).

    % read a term into the head of the result list,
    % then recursively call again to add rest of source to tail of list
read_file(ID,[Clause|Rest_of_file]) :-
    read_term(ID,Clause,[]), Clause \= end_of_file,!,
    writeq(Clause),write(.), nl,
    read_file(ID, Rest_of_file).
    
read_file(_,[]). % this clause is only reached when above fails at end_of_file

/* write a list of Prolog clause terms to a file */

output_file(File, Src) :-
    open(File,write,ID),
    write_file(ID, Src),
    close(ID).

write_file(ID, [Clause|Rest_of_file]) :-
    writeq(ID,Clause), write(ID,.), nl(ID), !, % write a period and newline after each clause
    write_file(ID,Rest_of_file).

write_file(_,[]).

/* Assert all the clauses in a list to current Prolog database */

assert_list([]).
assert_list([X|Rest]) :- assertz(X),assert_list(Rest).
