
/* simple prolog test program */
a(1).
a(2).
a(X) :- b(X).
b(3).
b(4).

