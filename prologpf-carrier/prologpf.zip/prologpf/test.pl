
a(b,c).
d(e,f).
init :- g_assign(z,3).