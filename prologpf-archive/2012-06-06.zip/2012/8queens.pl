get_solutions(Board_size, Soln) :- solve(Board_size, [], Soln). 

solve(Bs, [square(Bs, Y) | L], [square(Bs, Y) | L]).
solve(Board_size, Initial, Final) :-
		newsquare(Initial, Next, Board_size),
		solve(Board_size, [Next | Initial], Final).

newsquare([square(I,J) | Rest], square(X, Y), Boardsize) :-
	I < Boardsize, X is I + 1, snint(Y, Boardsize),
	notthreatened(I, J, X, Y), safe(X, Y, Rest).
newsquare([], square(1, X), Boardsize) :- snint(X, Boardsize).

snint(X, X).
snint(N, NPlusOneOrMore) :- M is NPlusOneOrMore - 1, M > 0,
	snint(N,M).

notthreatened(I, J, X, Y) :- I \== X, J \== Y, 
	U1 is I - J, V1 is X - Y, U1 \== V1,
	U2 is I + J, V2 is X + Y, U2 \== V2.

safe(X, Y, []).
safe(X, Y, [square(I, J) | L]) :-
	notthreatened(I, J, X, Y), safe(X, Y, L).

print_solution(N,Solution) :-
    print_board(N,N,Solution).
    
print_board(0,Cols,_).

print_board(Row,Cols,Solution) :-
    Row \= 0,
    print_row(Row,Cols,Solution), nl,write('----'),nl,
    N is Row - 1,
    print_board(N,Cols,Solution).
    
print_row(Row,0,_).

print_row(Row,Col,Solution) :-
    Col \= 0,
    (member(square(Row,Col),Solution) -> write(' X |') ; write('   |')),
    N is Col - 1,
    print_row(Row,N,Solution).
    
    
